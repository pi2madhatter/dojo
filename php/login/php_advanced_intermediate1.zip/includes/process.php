<?php
session_start();
//require('connection.php');


function illegal_character_check($string, $type)
//$type = (alphabetic = alpha, numeric = num, both = alphanum)
{
	if($type == 'alpha' && preg_match("/[^a-zA-Z]+/", $string))
	{
		return "bad";
	}
	elseif($type == 'num' && preg_match("/[^0-9]+/", $string))
	{
		return "bad";
	}
	elseif(preg_match("/[^a-zA-Z0-9]+/", $string))
	{
		return "bad";
	}
}

function names_evaluator($name, $label)
//got the first_name value ("") and label (first_name) to evaluate...
{
	$label_string = str_replace('_', ' ', ucwords($label));
	//if the value is "", then alert it and move on...
	if($name == "")
	{
		$alert[$label.'_required'] = $label_string . " is a required field.";
	}
	 else
	{
		//otherwise check the values for length...
		if(strlen($name) > 14)
	 	{
	 		$alert[$label.'_character_exceeded'] = $label_string . " must be less than 14 characters.";
	 	}
	 	//and feed into illegal character check for bad characters...
	 	if(illegal_character_check($name,'alpha') == 'bad')
	 	{
	 		$alert[$label.'_bad_characters'] = $label_string . " must use alphabetic characters only.";
	 	}
	}
	if(isset($alert)){
		return $alert;
	}
	else
	{
		return array();
	}
}

function passwords_evaluator($name, $label)
{
	$label_string = str_replace('_', ' ', ucwords($label));
	//if the value is "", then alert it and move on...
	if($name == "")
	{
		$alert[$label.'_required'] = $label_string . " is a required field.";
	}
	else {
		//otherwise check the values of the length...
		if(strlen($name) < 4 || strlen($name) > 8)
	 	{
	 		$alert[$label.'_length_exceed'] = $label_string . " must be between 4 and 8 characters.";
	 	}
	 	if(illegal_character_check($name,'both') == 'bad')
	 	{
	 		$alert[$label.'_bad_characters'] = $label_string . "must use alphanumeric characters only.";
	 	}
	}
	if(isset($alert)){
		return $alert;
	}
	else
	{
		return array();
	}
}

//in comes array with entries from all fields...
function validator($login_info)
{
	$collected_alerts = array();
//First Name evaluator
	//this takes the text from the first_name slot and the tag 'first_name' and pushes them to the names_evaluator function...
	$first_name_alerts = (names_evaluator($login_info['first_name'], 'first_name'));
	$collected_alerts = array_merge($collected_alerts, $first_name_alerts);
//Last Name evaluator
	//this takes the text from the last_name slot and the tag 'last_name' and pushes them to the names_evaluator function...
	$last_name_alerts = (names_evaluator($login_info['last_name'], 'last_name'));
	$collected_alerts = array_merge($collected_alerts, $last_name_alerts);

	//Password matching
	if($login_info['password'] !== $login_info['confirm_password'])
 	{
 		$collected_alerts['passwords_mismatch'] = "Passwords do not match.";
 	}
 	else
 	{
 	//Password evaluator
		$passwords_alerts = (passwords_evaluator($login_info['password'], 'password'));
		$collected_alerts = array_merge($collected_alerts, $passwords_alerts);
 	}
	if(empty($collected_alerts))
	{
		$collected_alerts = array('success'=>'<span class="success">Your submission was successful.<br />Thanks for submitting your information.</span>');
	}
	return $collected_alerts;
}	

$_SESSION['messages'] =(validator($_POST));
header("Location:../php_advanced_intermediate1.php");

?>